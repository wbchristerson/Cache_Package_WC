from setuptools import setup

setup(name='caches_WC',
      version='0.1',
      description='LRU cache and LFU cache implementations',
      packages=['caches_WC'],
      author='William Christerson',
      author_email='wbchristerson@gmail.com',
      zip_safe=False)
